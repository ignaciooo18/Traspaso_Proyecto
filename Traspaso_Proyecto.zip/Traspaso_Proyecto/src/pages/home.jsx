
import Hero from '../Components_General/Hero';
import MainContent from '../Components_General/main';
import '../App.css'
function Home() {
 return(
  <div>
    <Hero/>
    <MainContent/>
  </div>
 );

}

export default Home
