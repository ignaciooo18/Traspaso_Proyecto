import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import Button from 'react-bootstrap/Button';
import { Link, useNavigate } from 'react-router-dom';

function MiNavbar({ navItems = [] }) { 
  
  const navigate = useNavigate();
  const handleLogout = () => {
    navigate('/login');
  };

  return (
    <Navbar expand="lg" className="bg-body-tertiary" data-bs-theme="white">
      <Container>
        
        <Navbar.Brand as={Link} to="/">
          <img
            src='../img/PetSocietylogo - copia.webp'
            alt='imagen de mi pet society'
            width="70"
            height="50"
          />
        </Navbar.Brand>
        
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            {navItems.map((item, index) => (
              <Nav.Link key={index} as={Link} to={item.path}>
                {item.label}
              </Nav.Link>
            ))}
          </Nav>
          <div className="d-flex">
            <Button 
              variant="outline-secondary" 
              className="rounded-pill px-4"
              onClick={handleLogout}
            >
              Cerrar sesión
            </Button>
          </div>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default MiNavbar;